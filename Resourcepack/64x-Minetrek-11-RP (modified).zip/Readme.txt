This Version was modified by Felix T. Vogel.

Original:
Official Server 64x Resource Pack v11 Additions by BurntBiscuits, DeathMonkey, huansolo, Bluegobln, iPANIC14/iPanic, Atrocities, mheller3000, Bluephobes, Honkalonka, ChrisRyot and ShadowApler77.

Resourcepack downloaded from:
https://minetrek5.weebly.com/
https://www.dropbox.com/s/x3yijssys1vuu8z/MineTrek_Modpack_Full.zip?dl=1