Save and resource pack are build for Minecraft Version 1.12.2.
Best to use the modified resource pack, but the original is included.

Put the save in the saves folder.